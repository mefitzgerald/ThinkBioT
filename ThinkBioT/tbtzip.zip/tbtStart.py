#! /usr/local/bin/python3

print('Hello, world!')